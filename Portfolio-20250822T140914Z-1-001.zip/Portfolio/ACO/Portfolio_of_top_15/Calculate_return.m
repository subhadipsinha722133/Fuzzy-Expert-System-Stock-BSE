function [ret,rat,P_return]=Calculate_return(a_tour,a_cities)
ratio=randomx(15);
ratio=sort(ratio,'descend');
rat=ratio;
%Optimization Function(Return Parameters)%
E_A=xlsread('expected_return');
E_A=E_A';
Var_A=xlsread('variance');
Var_A=Var_A';
Skew_A=xlsread('skewness');
Skew_A=Skew_A';

R_F=0.01;
Beta=0.5;
Alpha=0.05;
Gamma=0.001;
m=0.05;
M=0.8;
R_P=0;
V_P=0;
S_P=0;
Meu_S=0.0014;
for i=1:15
    pos= find(strcmp(a_tour(i),a_cities)==1);
    R_P=R_P+E_A(pos)*ratio(i);
    V_P=V_P+Var_A(pos)*ratio(i);
    S_P=S_P+Skew_A(pos)*ratio(i);
end
P_return=(R_P-R_F)/Meu_S;
ret=P_return;
% if (R_P>=Alpha && V_P<=Beta && S_P>=Gamma)
%     ret=P_return;
% else
%     ret=0;
% end


end
    