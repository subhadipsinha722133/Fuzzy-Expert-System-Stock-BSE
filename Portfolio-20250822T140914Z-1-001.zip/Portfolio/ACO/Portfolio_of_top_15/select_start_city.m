function [city]=select_start_city(all_cities)
x=randi(15,1);
city=all_cities(x);
end