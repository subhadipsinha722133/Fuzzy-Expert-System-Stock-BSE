%ACO initialization%
Total_ants=30;
Total_securities=15;
Total_iterations=20;
Pheromone_mat=zeros(Total_ants,Total_ants);
all_cities=cities';
startcityofant=cell(1,Total_ants);        
%Heuristic_value=zeros(1,10);
ant_tour=cell(Total_ants,Total_securities);
%visited_cities=cell(30,30);
individual_returns=zeros(1,Total_ants);
maximum_returns=zeros(1,Total_iterations);
individual_ratios=zeros(Total_ants,Total_securities);
maximum_ratios=zeros(Total_iterations,Total_securities);
best_tour=cell(1,Total_securities);
best_ratio=zeros(1,Total_securities);

%Heuristic_value=[1 2 3 4 5 6 7 8 9 10];
        
for iteration=1:Total_iterations
for i=1:Total_ants
    start_city=select_start_city(all_cities);
    
    startcityofant(i)=start_city;
    ant_tour(i,1)=start_city;
    %visited_cities(i,1)=start_city;
    current_city=start_city;
   
    rem_cities=all_cities;
    
    for j=2:Total_securities
      c_city_index=find(strcmp(rem_cities,current_city)==1);  %calculating current city index;
      rem_cities(c_city_index)=[];
      n_city=select_next_city(c_city_index,rem_cities,Pheromone_mat,all_cities); %Finding the next city to visit;
      ant_tour(i,j)=n_city;
      current_city=n_city;
    end
    
    [returnoftour,current_ratio]=Calculate_return(ant_tour(i,:),all_cities);
    individual_returns(i)=returnoftour;
    individual_ratios(i,:)=current_ratio;
         
end

    max_return=max(individual_returns);
    ant_with_max_return=find(individual_returns==max_return);
    best_tour=ant_tour(ant_with_max_return,:);
    best_ratio=individual_ratios(ant_with_max_return,:);
    %Updation of Pheromone Matrix%
    
    for k=1:(Total_securities-1)
    ith_index=find(strcmp(all_cities,best_tour(k))==1);
    jth_index=find(strcmp(all_cities,best_tour(k+1))==1);
    Pheromone_mat(ith_index,jth_index)=Pheromone_mat(ith_index,jth_index)+2;
    end
maximum_returns(iteration)=max_return;
maximum_ratios(iteration,:)=best_ratio;
end
final_max_return=max(maximum_returns);
max_return_index=find(maximum_returns==final_max_return);
final_best_ratio=maximum_ratios(max_return_index,:);
