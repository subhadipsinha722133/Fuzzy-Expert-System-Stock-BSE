function [out]=randomx(n)

a= (0.8-0.06)*rand(1,n)+0.06;
out=a/sum(a)*1;
out(1)=out(1)-sum(out)+1;
end

