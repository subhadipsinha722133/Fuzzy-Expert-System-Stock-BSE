function [city]=select_next_city(P_mat,C_index,N_cities,S_nodes)

if(P_mat==0)
    
 ran1=randi([1,length(N_cities)],1,1);
       
city=N_cities(ran1);

else
    z=length(N_cities);
    P_concentration=zeros(1,z);
    N_indexes=zeros(1,z);
    count=0;
    
   
    for i=1:z
        N_indexes(i)=datasample(find(S_nodes==N_cities(i)),1);
        P_concentration(i)=P_mat(C_index,N_indexes(i));
    end
    max_con=max(P_concentration);
    
    for j=1:z
    if(P_mat(C_index,N_indexes(j))==max_con)
        count=count+1;
    end
       
    end
    pos_max_con=zeros(1,count);
    pos_max_con= find(P_mat(C_index,N_indexes)==max_con);
    ran=randi([1,count],1,1);
    x=pos_max_con(ran);
    city=N_cities(x);
    
end

               
end
