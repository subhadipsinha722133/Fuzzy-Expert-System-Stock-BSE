%ACO initialization%
Total_ants=50;
Total_securities=10;
Total_iterations=500;
T_nodes=2000;
lifetime=20;
Sol_nodes=zeros(1,T_nodes);
Sol_returns=zeros(1,T_nodes);

Sol_ratios=zeros(T_nodes,Total_securities);
startcityofant=zeros(1,Total_ants);
ant_tour=zeros(Total_ants,lifetime);
Pheromone_mat=zeros(T_nodes,T_nodes);
N_neighbour=T_nodes;
Neighbour_cities=zeros(1,N_neighbour);
final_sol=zeros(1,Total_ants);
max_return=zeros(1,Total_iterations);
%ant_at_best=zeros(1,Total_iterations);
optimum_sol=zeros(1,Total_iterations);
ants_at_optimum_obj=zeros(1,Total_iterations);

%Genrating N random solutions%

for N=1:T_nodes
    [Obj_val,Ratio,Return]=Calculate_return(Total_securities,E_A,Var_A,Skew_A,Semivariance);
    Sol_nodes(N)=Obj_val;
    Sol_returns(N)=Return;
    Sol_ratios(N,:)=Ratio;
end

%Visit of Ants%

for iteration=1:Total_iterations 
for A=1:Total_ants
    start_city=select_start_city(Sol_nodes);
    startcityofant(A)=start_city;
    ant_tour(A,1)=start_city;
    current_city=start_city;
   % Rem_cities=Sol_nodes;
    %c_city_index=find(Rem_cities==current_city);
c_city_index=datasample(find(Sol_nodes==current_city),1);

    for L=2:lifetime
        
        Current_node_value=Sol_nodes(c_city_index);
        Neighbour_cities=Generate_neighbour(Sol_nodes,N_neighbour);
        Next_city=select_next_city(Pheromone_mat,c_city_index,Neighbour_cities,Sol_nodes);
        
        if(Next_city>current_city)
        Current_index=find(Sol_nodes==current_city);
        Next_index=find(Sol_nodes==Next_city);
        Pheromone_mat(Current_index,Next_index)=Pheromone_mat(Current_index,Next_index)+2;
        current_city=Next_city;
        c_city_index=find(Sol_nodes==current_city);
        ant_tour(A,L)=Next_city;
       % Rem_cities(c_city_index)=[];
        else
            ant_tour(A,L)=current_city;
            %current_city=Next_city;
        end
    end
    final_sol(A)=ant_tour(A,lifetime);
end

%Objective value in each iteartion%
unique_sols=unique(final_sol);          %No of unique solutions where ants have reached after their lifetime in each iteration.
length_unique_sols=length(unique_sols); % Number of unique solutions.
unique_sol_count=zeros(1,length_unique_sols);   
for l=1:length_unique_sols
unique_sol_count(l)=sum(final_sol==unique_sols(l)); %Number of ants accumulated in each unique solutions.
end
max_unique_sol=max(unique_sol_count);               %Maximum number of ant accumualted in any unique solution.
ants_at_optimum_obj(iteration)=max_unique_sol;
max_unique_sol_index=find(unique_sol_count==max_unique_sol);
optimum_obj_val=unique_sols(max_unique_sol_index);
optimum_sol(iteration)=max(optimum_obj_val);

% best_sol=max(final_sol);

 best_index=find(final_sol==optimum_sol(iteration));
 best_tour=ant_tour(best_index,:);
% optimum_sol(iteration)=best_sol;

%  count=0;
%  for x=1:Total_ants
%      if(final_sol(x)==optimum_sol(iteration))
%           count=count+1;
%       end
% end

%ant_at_best(iteration)=count;

best_index_length=length(best_index);
for T=1:best_index_length
   
    best_tour=ant_tour(best_index(T),:);
    
%Global Pheromone Updation%
for k=1:(lifetime-1)
     ith_index=find(Sol_nodes==best_tour(k));
     jth_index=find(Sol_nodes==best_tour(k+1));
     Pheromone_mat(ith_index,jth_index)=Pheromone_mat(ith_index,jth_index)+0.5;
end
end
 
 %Pheromone Evaporation%0
 for a=1:(T_nodes)
    for b=1:(T_nodes)
        Pheromone_mat(a,b)=Pheromone_mat(a,b)-0.05;
    end
end
 
end

%  final_sol_index=find(Sol_nodes==best_sol);
%  final_best_return=Sol_returns(final_sol_index);
%  final_best_ratio=Sol_ratios(final_sol_index,:);

x_axis=linspace(1,Total_iterations,Total_iterations);
%y=ant_at_best;
y=optimum_sol;
y_axis=y(x_axis);
plot(x_axis,y_axis);

 figure

 x1_axis=linspace(1,Total_iterations,Total_iterations);
 y=ants_at_optimum_obj;
 y_axis=y(x1_axis);
 plot(x1_axis,y_axis);
        
        

    %visited_cities(i,1)=start_city;
    

% Pheromone_mat=zeros(Total_securities,Total_securities);
% all_cities=cities';
% startcityofant=cell(1,Total_ants);        
% %Heuristic_value=zeros(1,10);
% ant_tour=cell(Total_ants,Total_securities);
% %visited_cities=cell(30,30);
% individual_returns=zeros(1,Total_ants);
% Expected_Return=zeros(1,Total_ants);
% maximum_returns=zeros(1,Total_iterations);
% maximum_expected_returns=zeros(1,Total_iterations);
% individual_ratios=zeros(Total_ants,Total_securities);
% maximum_ratios=zeros(Total_iterations,Total_securities);
% best_tour=cell(1,Total_securities);
% best_ratio=zeros(1,Total_securities);
% max_return=0;
% current_max_return=0;
% 
% %Heuristic_value=[1 2 3 4 5 6 7 8 9 10];
%         
% for iteration=1:Total_iterations
% for i=1:Total_ants
%     start_city=select_start_city(all_cities,Total_securities,best_tour,iteration);
%     
%     startcityofant(i)=start_city;
%     ant_tour(i,1)=start_city;
%     %visited_cities(i,1)=start_city;
%     current_city=start_city;
%    
%     rem_cities=all_cities;
%     
%     for j=2:Total_securities
%       c_city_index=find(strcmp(rem_cities,current_city)==1);  %calculating current city index;
%       rem_cities(c_city_index)=[];
%       [n_city]=select_next_city(c_city_index,rem_cities,Pheromone_mat,all_cities); %Finding the next city to visit;
%       ant_tour(i,j)=n_city;
%       current_city=n_city;
%     end
%     
%     [returnoftour,current_ratio,Ex_Ret]=Calculate_return(ant_tour(i,:),all_cities,Total_securities);
%     individual_returns(i)=returnoftour;
%     individual_ratios(i,:)=current_ratio;
%     Expected_Return(i)=Ex_Ret; 
%     
%     %Local Pheromone Updation%
%     
%     if (returnoftour>max_return)
%         for l=1:(Total_securities-1)
%         ith_index=find(strcmp(all_cities,ant_tour(i,l))==1);
%         jth_index=find(strcmp(all_cities,ant_tour(i,l+1))==1);
%         Pheromone_mat(ith_index,jth_index)=Pheromone_mat(ith_index,jth_index)+2;
%         end
%     max_return=returnoftour;    
%     end
%     
%     
%          
% end    %end of each ant%
% 
%     max_return=max(individual_returns);
%     max_expected_return=max(Expected_Return);
%     ant_with_max_return=find(individual_returns==max_return);
%     best_tour=ant_tour(ant_with_max_return,:);
%     best_ratio=individual_ratios(ant_with_max_return,:);
%    
%     % Global Updation of Pheromone Matrix%
%     
%     if(max_return>current_max_return)
%         
%     for k=1:(Total_securities-1)
%     ith_index=find(strcmp(all_cities,best_tour(k))==1);
%     jth_index=find(strcmp(all_cities,best_tour(k+1))==1);
%     Pheromone_mat(ith_index,jth_index)=Pheromone_mat(ith_index,jth_index)+2;
%     end
%     current_max_return=max_return;
%     end
%     
%     
%     
% maximum_returns(iteration)=max_return;
% maximum_ratios(iteration,:)=best_ratio;
% maximum_expected_returns(iteration)=max_expected_return;
% 
% % Pheromone Evaporation%
% for a=1:(Total_securities)
%     for b=1:(Total_securities)
%         Pheromone_mat(a,b)=Pheromone_mat(a,b)-0.1;
%     end
% end
% 
% end
% final_max_return=max(maximum_returns);
% final_max_expected_return=max(maximum_expected_returns);
% max_return_index=find(maximum_returns==final_max_return);
% final_best_ratio=maximum_ratios(max_return_index,:);
