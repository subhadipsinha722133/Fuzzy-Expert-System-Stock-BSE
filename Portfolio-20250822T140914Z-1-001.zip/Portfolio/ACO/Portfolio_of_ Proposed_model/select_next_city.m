function [city]=select_next_city(C_index,R_city,P_mat,a_cities)
if(P_mat==0)
    ran1=randi([1,length(R_city)],1,1);
    
city=R_city(ran1);
else
    z=length(R_city);
    P_concentration=zeros(1,z);
    R_indexes=zeros(1,z);
    pos_max_con=zeros(1,z);
    for i=1:z
        R_indexes(i)=find(strcmp(a_cities,R_city(i))==1);
        P_concentration(i)=P_mat(C_index,R_indexes(i));
    end
    max_con=max(P_concentration);
    for j=1:z
    pos_max_con= P_mat(C_index,R_indexes(j))==max_con;
    end
    len=length(pos_max_con);
    ran=randi([1,len],1,1);
    city=R_city(ran);
    
end

               
end
