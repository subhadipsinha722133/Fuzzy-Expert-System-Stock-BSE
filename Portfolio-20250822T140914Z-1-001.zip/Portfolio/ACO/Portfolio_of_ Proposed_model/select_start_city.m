function [city]=select_start_city(all_cities,T_securities)
x=randi(T_securities,1);
city=all_cities(x);
end