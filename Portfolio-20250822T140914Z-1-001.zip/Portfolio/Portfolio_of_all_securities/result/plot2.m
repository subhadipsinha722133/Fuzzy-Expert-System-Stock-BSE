 X=ants_at_optimum_obj;
% Y=Total_iterations;
figure;
title('Ant accumulation at optimum objective value');
plot(X)
xlabel('Iteration');
ylabel('Ants at optimum objective value');
legend('Total Number of Ants at Optimal Objective Value');