 X=optimum_sol;
% Y=Total_iterations;
figure;
plot(X)
xlabel('Iteration');
ylabel('Optimal Objective Value');
legend('Optimal Objective Value');
