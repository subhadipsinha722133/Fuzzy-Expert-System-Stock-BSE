function [out]=random(n)
a=rand(1,n);
out=a/sum(a)*m;
out(1)=out(1)-sum(out)+m;
end

