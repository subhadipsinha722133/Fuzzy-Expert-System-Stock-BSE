function [arr]=test(n)
arr=zeros(1,5);
for i=1:5
    arr(i)=i;
end
end