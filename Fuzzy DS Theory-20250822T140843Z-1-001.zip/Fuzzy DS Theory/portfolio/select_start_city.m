function [city]=select_start_city(S_nodes)
size=length(S_nodes);
x=randi(size,1);
city=S_nodes(x);

end