function [ret,rat,R_P]=Calculate_return(T_securities,E_A,Var_A,Skew_A,Semivariance)
ratio=randomx(T_securities);
ratio=sort(ratio,'descend');
rat=ratio;
%Optimization Function(Return Parameters)%
%E_A=xlsread('expected_return');
E_A=E_A';
%Var_A=xlsread('variance');
Var_A=Var_A';
%Skew_A=xlsread('skewness');
Skew_A=Skew_A';
%Semivariance=xlsread('semivariance');
Semivariance=Semivariance';

R_F=0.01;
Beta=0.5;
Alpha=0.05;
Gamma=0.001;
R_P=0;
V_P=0;
S_P=0;
Meu_S=0;
for j=1:T_securities
    Meu_S=Meu_S+(ratio(j)*Semivariance(j));
end

for i=1:T_securities
    R_P=R_P+E_A(i)*ratio(i);
    V_P=V_P+Var_A(i)*ratio(i);
    S_P=S_P+Skew_A(i)*ratio(i);
end
P_return=(R_P-R_F)/Meu_S;
ret=P_return;
% if (R_P>=Alpha && V_P<=Beta && S_P>=Gamma)
%     ret=P_return;
% else
%     ret=0;
% end


end
    