function [N_cities]=Generate_neighbour(R_cities,N_Nbr)
L=length(R_cities);
N_city_index=randi([1,L],N_Nbr,1);
N_cities=R_cities(N_city_index);
% i=1;
% N_cities=zeros(1,N_Nbr);
% while (i<N_Nbr+1)
% L=length(R_cities);
% N_city_index=randi([1,L],1,1);
% City_val=R_cities(N_city_index);
% if(City_val>C_val)
%     N_cities(i)=City_val;
%     i=i+1;
%     R_cities(N_city_index)=[];
% end
    

end
    
