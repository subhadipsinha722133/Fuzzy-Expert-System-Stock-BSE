% readme.txt for speauth.cls
% Version 3.0 released 13 May 2010
%
% This software may only be used to prepare an article for publication in
% Software---Practice and Experience
% to be published by John Wiley & Sons, Ltd.
% Any other use constitutes an infringement of copyright.
%
% The release consists of the following files:
%
%   readme.txt   this file
%   speauth.cls  the LaTeX2e class file
%   spedoc.tex   authors' instructions
%   spedoc.pdf   authors' instructions in PDF format
%
% Typeset spedoc.tex for instructions and examples, or view the PDF.
%
%
%
% Please note that the file wileyj.bst is available from the same download
% page for those authors using BibTeX.

